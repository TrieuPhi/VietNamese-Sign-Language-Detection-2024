﻿# **1. THIẾT KẾ VÀ KIẾN TRÚC HỆ THỐNG**
## **1.1.	 Sơ đồ khối![A diagram of a data storage system

Description automatically generated](Aspose.Words.d7b39af0-c158-4eab-bde8-68b6f7301708.001.png)**

## **1.2.	 Sử dụng sơ đồ trường hợp**
![A diagram of a person's diagram

Description automatically generated](Aspose.Words.d7b39af0-c158-4eab-bde8-68b6f7301708.002.png)


## **1.3.	Sơ đồ luồng dữ liệu**
![A diagram of a data flow

Description automatically generated](Aspose.Words.d7b39af0-c158-4eab-bde8-68b6f7301708.003.png)![A diagram of a hand gestures

Description automatically generated](Aspose.Words.d7b39af0-c158-4eab-bde8-68b6f7301708.004.png)


# **2. CÁCH CHẠY CHƯƠNG TRÌNH**

## **2.1. Yêu cầu hệ thống**

### **2.1.1. 	Đặc điểm phần cứng**
- 3 GB ổ đĩa miễn phí
- RAM 8GB
- CPU/GPU lõi tứ
### **2.1.2. 	Đặc tả phần mềm**
- Hệ điều hành – Windows/MAC/LINUX
- Python - Để tạo mã nguồn và thuật toán
## **2.2. Python > 3.9** 
Tiến hành cài đặt file requirement.txt 

Run à  final\_pred.py 






